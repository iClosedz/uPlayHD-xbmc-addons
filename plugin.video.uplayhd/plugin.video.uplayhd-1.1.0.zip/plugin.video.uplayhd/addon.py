#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2013 iClosedz (iClosedz.blogspot.com)
#	 Thanks to sphere (https://github.com/dersphere)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import string
from xbmcswift2 import Plugin, xbmcgui, xbmcaddon, xbmc
from resources.lib import scraper, scraper_ru

addon_id = 'plugin.video.uplayhd'
STRINGS = {
	'page': 00001,
	'exit': 00002,
	'download': 60000,
	'download_in_progress': 70000,
	'downloaded': 70001,
	'us_series': 10000,
	'kr_series': 10001,
	'jp_series': 10002,
	'cn_series': 10003,
	'anime': 10004,
	'th_series': 10005,
	'movies': 10006,
	'sports': 10007,
	'kids': 10008,
	'cartoons': 10009,
	'tv': 10010,
	'kr_ru_series': 10011,
	'jp_ru_series': 10012,
	'cn_s': 20010,
	'tw_s': 20011,
	'ch_3': 20050,
	'ch_5': 20051,
	'ch_7': 20052,
	'ch_9': 20053,
	'ch_etc': 20054,
	'latest': 30000,
	'orderby': 30001,
	'newupdate': 30002,
	'search': 30003,
	'orderby_az': 30004,
	'orderby_genre': 30005,
	'orderby_ch': 30006,
	'orderby_ct': 30007,
	'no_download_path': 60001,
	'want_set_now': 60002,
	'site_unavailable': 60003,
	'try_again_later': 60004,
	'network_error': 70002,
	'show_my_favs': 80000,
	'add_to_my_favs': 80001,
	'del_from_my_favs': 80002,
	'no_my_favs': 80003,
	'use_context_menu': 80004,
	'to_add': 80005
	
}

plugin = Plugin()

@plugin.route('/')
def index():
	items = []
	items.append({
		'label': _('show_my_favs'),
		'path': plugin.url_for('show_my_favs').encode('utf-8'),
		'thumbnail': get_image_path('bookmark.png')
	})
	items.extend([{
		'label': _(category1['title']),
		'path': plugin.url_for(category1['path'], stype=category1['stype']).encode('utf-8')
	} for category1 in scraper.get_categories1()])
	
	return plugin.finish(items)

@plugin.route('/series/<stype>/')
def show_series(stype):
	items = []
	items.extend([{
		'label': _(category2_1['title']),
		'path': plugin.url_for(category2_1['path'], stype=stype, soption=category2_1['soption'], page='1').encode('utf-8')
	} for category2_1 in scraper.get_categories2_1()])
	if stype == 's_us' or stype == 's_kr':
		items.extend([{
			'label': _(category2_2['title']),
			'path': plugin.url_for(category2_2['path'], stype=stype, soption=category2_2['soption']).encode('utf-8')
		} for category2_2 in scraper.get_categories2_2()])
	elif stype == 'sc_th':
		items.append({
			'label': _('orderby_ch'),
			'path': plugin.url_for('show_orderby', stype=stype, soption='orderby_ch').encode('utf-8')
		})
	elif stype == 'sc_cn':
		items.append({
			'label': _('orderby_ct'),
			'path': plugin.url_for('show_orderby', stype=stype, soption='orderby_ct').encode('utf-8')
		})	
	return plugin.finish(items)

@plugin.route('/movies/<stype>/')
def show_movies(stype):
	items = []
	items.extend([
		{'label': _('latest'),
			'path': plugin.url_for('show_names', stype=stype, soption='latest', page='1').encode('utf-8')},
		{'label': _('orderby'),
			'path': plugin.url_for('show_names', stype=stype, soption='orderby', page='1').encode('utf-8')},
		{'label': _('search'),
			'path': plugin.url_for('show_search', stype=stype, soption='search', page='1').encode('utf-8')}
	])
	items.extend([{
		'label': _(category2_2['title']),
		'path': plugin.url_for(category2_2['path'], stype=stype, soption=category2_2['soption']).encode('utf-8')
	} for category2_2 in scraper.get_categories2_2()])
	return plugin.finish(items)

@plugin.route('/links/<stype>/')
def show_links(stype):
	links = scraper.get_links(stype)
	items = []
	for i, link in enumerate(links):
		url = link['source']
		thumb = link['thumb']
		title = link['title']
		items.extend([{
			'label': title,
			'thumbnail': thumb,
			'info': {
				'count': i,
			},
            'is_playable': True,
			'path': plugin.url_for(
				endpoint='play_video',
				url=link['source']
			).encode('utf-8')
		}])
	return plugin.finish(items)

################################################## RUindy ##################################################
@plugin.route('/ru_series/<stype>/')
def show_ru_series(stype):
	items = []
	items.extend([{
		'label': _(category_ru['title']),
		'path': plugin.url_for(category_ru['path'], stype=stype, soption=category_ru['soption']).encode('utf-8')
	} for category_ru in scraper_ru.get_categories_ru()])
	return plugin.finish(items)

@plugin.route('/videos/<stype>/<soption>/ruindy/series/search/<key>', name='show_ru_names_search')
@plugin.route('/videos/<stype>/<soption>/ruindy/series/orderby/<key>', name='show_ru_names_orderby')
@plugin.route('/videos/<stype>/<soption>/ruindy/series', options={'key': '0'})
def show_ru_names(stype, soption, key):
	temp_items = plugin.get_storage('temp_items')
	temp_items.clear()

	names = scraper_ru.get_names(stype, soption, key)
	if key != '0':
		endp0 = 'show_ru_names_orderby'
	else:
		endp0 = 'show_ru_names'	
		
	items = []	
	items.extend([{
		'label': name['title']+name['statusname'], #+' Update ('+name['lastupdated']+')',
		'thumbnail': name['thumb'],
		'info': {
			'count': i,
			#'genre': name['genre'],
			#'year': name['year'],
			#'episode': name['numberofep'],
			#'director': name['director'],
			'plot': name['plot'],
			#'plotoutline': name['prodcom'],
			'title': name['title'],
			#'studio': name['studio'],
			#'writer': name['writer'],
			'tvshowtitle': name['title'],
			#'premiered': name['year'],
			'status': name['statusname'],
			#'trailer': name['trailer']
		},
		'path': plugin.url_for(
			endpoint=show_ru_episodes,
			stype=stype,
			soption=soption,
			name_id=name['id']
		).encode('utf-8')
	} for i, name in enumerate(names)])
	
	for item in items:
		temp_items[item['path']] = item
		item['context_menu'] = context_menu_fav(item['path'])
	temp_items.sync()
	return plugin.finish(items, update_listing=True)

@plugin.route('/videos/<stype>/<soption>/ruindy/series/id/<name_id>/')
def show_ru_episodes(stype, soption, name_id):
	episodes = scraper_ru.get_episodes(name_id)
	downloads = plugin.get_storage('downloads')

	items = []
	for i, episode in enumerate(episodes):
		url = episode['source']
		title = 'EP ' + episode['part'] + ' (' + episode['date'] + ')'
		if url in downloads:
			import xbmcvfs  # FIXME: import from swift after fixed there
			if xbmcvfs.exists(downloads[url]):
				title = '%s - %s' % (title, _('already_downloaded'))
			#else:
				#download_status = _('download_in_progress')
		items.extend([{
			'label': title,
			'thumbnail': episode['thumb'],
			'info': {
				'count': i,
			},
			'context_menu': [
				(_('download'), 'XBMC.RunPlugin(%s)' % plugin.url_for(
				endpoint='download_video',
				url=episode['source']
			).encode('utf-8'))
            ],
            'is_playable': True,
			'path': plugin.url_for(
				endpoint='play_video',
				url=episode['source']
			).encode('utf-8')
		}])
	return plugin.finish(items)

################################################## Orderby #################################################
@plugin.route('/orderby/<stype>/<soption>/')
def show_orderby(stype, soption):
	items = []
	if soption == 'orderby_az':
		items.extend([{
			'label': chr(letter),
			'path': plugin.url_for('show_names_orderby', stype=stype, soption=soption, page='1', key=chr(letter)).encode('utf-8')
		} for letter in range(ord('A'), ord('Z') + 1)])
	elif soption == 'orderby_az3':
		char = 65
		#char = 97
		for i in range(0, 7):
			title = chr(char)+chr(45)
			key = chr(char+32)
			if i==6:
				title += chr(char+1)
				key += chr(char+33)
			else:
				title += chr(char+3)
				key += chr(char+35)
			char += 4
			items.append({
			'label': title,
			'path': plugin.url_for('show_ru_names_orderby', stype=stype, soption=soption, page='1', key=key).encode('utf-8')
			})
			
	elif soption == 'orderby_genre':
		items.extend([{
			'label': category3_2,
			'path': plugin.url_for('show_names_orderby', stype=stype, soption=soption, page='1', key=category3_2).encode('utf-8')
		} for category3_2 in scraper.get_categories3_2()])
	elif soption == 'orderby_ch':
		items.extend([{
			'label': _(category3_3['title']),
			'path': plugin.url_for('show_names_orderby', stype=stype, soption=soption, page='1', key=category3_3['cat']).encode('utf-8')
		} for category3_3 in scraper.get_categories3_3()])
	elif soption == 'orderby_ct':
		items.extend([{
			'label': _(category3_4['title']),
			'path': plugin.url_for('show_names_orderby', stype=stype, soption=soption, page='1', key=category3_4['cat']).encode('utf-8')
		} for category3_4 in scraper.get_categories3_4()])	
	return plugin.finish(items)


################################################## Series ##################################################

@plugin.route('/videos/<stype>/<soption>/page/<page>/orderby/<key>', name='show_names_orderby')	
@plugin.route('/videos/<stype>/<soption>/page/<page>', options={'key': '0'})
def show_names(stype, soption, page, key):
	
	temp_items = plugin.get_storage('temp_items')
	temp_items.clear()
	
	page = int(page)
	names = scraper.get_option(page, stype, soption, key)
	
	if stype == 'm_mo':
		#endp0 = 'show_movies'
		endp1 = 'show_movies_part'
	else:
		#endp0 = 'show_series'
		endp1 = 'show_episodes'
		
	if key != '0':
		endp0 = 'show_names_orderby'
	else:
		endp0 = 'show_names'	
		
	items = []
	if page > 1:
		previous_page = str(page - 1)
		items.append({
			'label': '<< %s %s <<' % (_('page'), previous_page),
			'thumbnail': get_image_path('prev.png'),
			'path': plugin.url_for(
				endpoint=endp0,
				stype=stype,
				soption=soption,
				page=previous_page,
				key=key,
				update='true'
			).encode('utf-8')
		})		
	items.extend([{
		'label': name['title']+name['statusname'], #+' Update ('+name['lastupdated']+')',
		'thumbnail': name['thumb'],
		'info': {
			'count': i,
			'genre': name['genre'],
			'year': name['year'],
			'episode': name['numberofep'],
			'director': name['director'],
			'plot': name['plot'],
			'plotoutline': name['prodcom'],
			'title': name['title'],
			'studio': name['studio'],
			'writer': name['writer'],
			'tvshowtitle': name['title'],
			'premiered': name['year'],
			'status': name['statusname'],
			'trailer': name['trailer']
		},
		'path': plugin.url_for(
			endpoint=endp1,
			stype=stype,
			soption=soption,
			page=page,
			name_id=name['id']
		).encode('utf-8')
	} for i, name in enumerate(names)])
	next_page = str(page + 1)
	items.append({
		'label': '>> %s %s >>' % (_('page'), next_page),
		'thumbnail': get_image_path('next.png'),
		'path': plugin.url_for(
			endpoint=endp0,
			stype=stype,
			soption=soption,
			page=next_page,
			key=key,
			update='true'
		).encode('utf-8')
	})
	
	for item in items:
		temp_items[item['path']] = item
		item['context_menu'] = context_menu_fav(item['path'])
	temp_items.sync()
	#plugin.set_content('tvshows')
	return plugin.finish(items, update_listing=True)
	#return plugin.finish(items)

@plugin.route('/videos/<stype>/<soption>/mname/<name_id>/')
def show_movies_part(stype, soption, name_id):
	movies = scraper.get_movies(name_id, stype)
	downloads = plugin.get_storage('downloads')
	items = []
	for i, movie in enumerate(movies):
		url = movie['source']
		title = movie['title']
		if url in downloads:
			import xbmcvfs  # FIXME: import from swift after fixed there
			if xbmcvfs.exists(downloads[url]):
				title = '%s - %s' % (title, _('already_downloaded'))
			#else:
				#download_status = _('download_in_progress')
		items.extend([{
			'label': title,
			'info': {
				'count': i,
			},
			'context_menu': [
				(_('download'), 'XBMC.RunPlugin(%s)' % plugin.url_for(
				endpoint='download_video',
				stype=stype,
				soption=soption,
				url=movie['source']
			).encode('utf-8'))
            ],
            'is_playable': True,
			'path': plugin.url_for(
				endpoint='play_video',
				url=movie['source']
			).encode('utf-8')
		}])
	return plugin.finish(items)

@plugin.route('/videos/<stype>/<soption>/newepisodes/', name='show_new_episodes', options={'page': '0', 'name_id': '0'})
@plugin.route('/videos/<stype>/<soption>/page/<page>/id/<name_id>/')
def show_episodes(stype, soption, page, name_id):
	if soption == 'newupdate':
		episodes = scraper.get_new_episodes(stype)
	else:
		episodes = scraper.get_episodes(name_id, stype)
	downloads = plugin.get_storage('downloads')

	items = []
	for i, episode in enumerate(episodes):
		url = episode['source']
		if soption == 'newupdate':
			thumb = episode['thumb']
			title = episode['title'] + ' EP ' + episode['part']+episode['status'] + ' (' + episode['date'] + ')'
		else:
			title = 'EP ' + episode['part'] + ' (' + episode['date'] + ')'
			thumb = ''
		if url in downloads:
			import xbmcvfs  # FIXME: import from swift after fixed there
			if xbmcvfs.exists(downloads[url]):
				title = '%s - %s' % (title, _('already_downloaded'))
			#else:
				#download_status = _('download_in_progress')
		items.extend([{
			'label': title,
			'thumbnail': thumb,
			'info': {
				'count': i,
			},
			'context_menu': [
				(_('download'), 'XBMC.RunPlugin(%s)' % plugin.url_for(
				endpoint='download_video',
				url=episode['source']
			).encode('utf-8'))
            ],
            'is_playable': True,
			'path': plugin.url_for(
				endpoint='play_video',
				url=episode['source']
			).encode('utf-8')
		}])
	return plugin.finish(items)

###############################################  Favs ###############################################	

def context_menu_fav(item_path):
	my_fav_items = plugin.get_storage('my_fav_items')
	if not item_path in my_fav_items:
		context_menu = [(
			_('add_to_my_favs'),
			'XBMC.RunPlugin(%s)' % plugin.url_for(
				endpoint='add_to_my_favs',
				item_path=item_path
			),
		)]
	else:
		context_menu = [(
			_('del_from_my_favs'),
			'XBMC.RunPlugin(%s)' % plugin.url_for(
				endpoint='del_from_my_favs',
				item_path=item_path
			),
		)]
	return context_menu
		
@plugin.route('/my_favs/')
def show_my_favs():

	def context_menu(item_path):
		context_menu = [(
			_('del_from_my_favs'),
			'XBMC.RunPlugin(%s)' % plugin.url_for('del_from_my_favs', item_path=item_path)
		)]
		return context_menu

	my_fav_items = plugin.get_storage('my_fav_items')
	items = my_fav_items.values()
	for item in items:
		item['context_menu'] = context_menu(item['path'])
	if not items:
		dialog = xbmcgui.Dialog()
		dialog.ok(_('no_my_favs'), _('use_context_menu'), _('to_add'))
		return
	return plugin.finish(items)

@plugin.route('/my_favs/add/<item_path>')
def add_to_my_favs(item_path):
	my_fav_items = plugin.get_storage('my_fav_items')
	temp_items = plugin.get_storage('temp_items')
	my_fav_items[item_path] = temp_items[item_path]
	my_fav_items.sync()


@plugin.route('/my_favs/del/<item_path>')
def del_from_my_favs(item_path):
	my_fav_items = plugin.get_storage('my_fav_items')
	if item_path in my_fav_items:
		del my_fav_items[item_path]
		my_fav_items.sync()	
	
###############################################  Play and Download ###############################################	

@plugin.route('/download/<url>/')
def download_video(url):
	import SimpleDownloader
	sd = SimpleDownloader.SimpleDownloader()
	playable_url = url
	download_path = plugin.get_setting('download_path')
	while not download_path:
		try_again = xbmcgui.Dialog().yesno(
			_('no_download_path'),
			_('want_set_now')
		)
		if not try_again:
			return
		plugin.open_settings()
		download_path = plugin.get_setting('download_path')
	filename = playable_url.split('?')[0].split('/')[-1]
	params = {
		'url': playable_url,
		'download_path': download_path
	}
	sd.download(filename, params)
	downloads = plugin.get_storage('downloads')
	downloads[url] = xbmc.translatePath(download_path + filename)
	downloads.sync()

@plugin.route('/play/<url>/')
def play_video(url):
	if url == 'null':
		dialog = xbmcgui.Dialog()
		dialog.ok('Sorry !', _('site_unavailable'), _('try_again_later'))
		return  # return None here
    
	downloads = plugin.get_storage('downloads')
	if url in downloads:
		local_file = downloads[url]
		# download was already started
		import xbmcvfs  # FIXME: import from swift after fixed there
		if xbmcvfs.exists(local_file):
			# download was also finished
			log('uPlayHD log => Using local file: %s' % local_file)
			return plugin.set_resolved_url(local_file)
	playable_url = url
	log('uPlayHD log => Using URL: %s' % playable_url)
	return plugin.set_resolved_url(playable_url)
		
############################################### Search #####################################################

@plugin.route('/search/<stype>/<soption>/')
def show_search(stype, soption):
	search_string = plugin.keyboard(heading=_('search'))
	if search_string:
		if stype == 's_ru_kr' or stype == 's_ru_jp':
			endpoint = 'show_ru_names_search'
			url = plugin.url_for(
				endpoint,
				stype = stype,
				soption = soption,
				key = search_string
			).encode('utf-8')	
		else:
			endpoint = 'search_result'
			url = plugin.url_for(
				endpoint,
				stype = stype,
				soption = soption,
				search_string = search_string
			).encode('utf-8')
		plugin.redirect(url)

@plugin.route('/search/<stype>/<soption>/<search_string>/')
def search_result(stype, soption, search_string):
	names = scraper.get_serch_result(stype, search_string)
	return add_search_result(stype, soption, names)

def add_search_result(stype, soption, names):
	temp_items = plugin.get_storage('temp_items')
	temp_items.clear()
	if stype == 'm_mo':
		endp = 'show_movies_part'
	else:
		endp = 'show_episodes'
	items = [{
		'label': name['title']+name['statusname'], #+' Update ('+name['lastupdated']+')',
		'thumbnail': name['thumb'],
		'info': {
			'count': i,
			'genre': name['genre'],
			'year': name['year'],
			'episode': name['numberofep'],
			'director': name['director'],
			'plot': name['plot'],
			'plotoutline': name['prodcom'],
			'title': name['title'],
			'studio': name['studio'],
			'writer': name['writer'],
			'tvshowtitle': name['title'],
			'premiered': name['year'],
			'status': name['statusname'],
			'trailer': name['trailer']
		},
		'path': plugin.url_for(
			endpoint=endp,
			stype=stype,
			soption=soption,
			page='0',
			name_id=name['id']
		).encode('utf-8')
	} for i, name in enumerate(names)]
	for item in items:
		temp_items[item['path']] = item
		item['context_menu'] = context_menu_fav(item['path'])
	#plugin.set_content('tvshows')
	return plugin.finish(items)	

########################################### Etc. #########################################################

def get_image_path(image):
    ''' get image path '''
    image = 'special://home/addons/{id}/resources/images/{image}'.format(
        id=addon_id, image=image)
    return image
	
def _(string_id):
	if string_id in STRINGS:
		return plugin.get_string(STRINGS[string_id])
	else:
		plugin.log.warning('uPlayHD error => String is missing: %s' % string_id)
		return string_id

def log(text):
	plugin.log.info(text)

if __name__ == '__main__':
	try:
		plugin.run()
	except scraper.NetworkError:
		plugin.notify(msg=_('network_error'))
