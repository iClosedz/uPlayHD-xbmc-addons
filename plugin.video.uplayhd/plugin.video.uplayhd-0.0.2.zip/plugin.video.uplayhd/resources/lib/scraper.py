#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#     Copyright (C) 2013 iClosedz (iClosedz.blogspot.com)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import urllib2,urllib,re
from BeautifulSoup import BeautifulSoup

usefull = {'stype': '', 'surl': '', 'poster': '', 'uagent': ''}
CATEGORIES1 = (
    {'title': 'us_series', 'path': 'show_series', 'stype': 's_us'},
	{'title': 'kr_series', 'path': 'show_series', 'stype': 's_kr'},
	{'title': 'jp_series', 'path': 'show_series', 'stype': 's_jp'},
	#{'title': 'cn_series', 'path': 'show_series_ch', 'stype': 'sc_cn'},
	#{'title': 'th_series', 'path': 'show_series_ch', 'stype': 'sc_th'},
	{'title': 'cn_series', 'path': 'show_series', 'stype': 'sc_cn'},
	{'title': 'th_series', 'path': 'show_series', 'stype': 'sc_th'},
	{'title': 'anime', 'path': 'show_series', 'stype': 's_an'},
	{'title': 'cartoons', 'path': 'show_series', 'stype': 's_ct'},
	{'title': 'movies', 'path': 'show_movies', 'stype': 'm_mo'},
	{'title': 'sports', 'path': 'show_links', 'stype': 'l_sp'},
	{'title': 'kids', 'path': 'show_links', 'stype': 'l_kd'}
)
CATEGORIES2_1 = (
    {'title': 'latest', 'path': 'show_names', 'soption': 'latest'},
	{'title': 'orderby', 'path': 'show_names', 'soption': 'orderby'},
	{'title': 'newupdate', 'path': 'show_new_episodes', 'soption': 'newupdate'},
	{'title': 'search', 'path': 'show_search', 'soption': 'search'}
)

class NetworkError(Exception):
    pass

def get_categories1():
    return CATEGORIES1

def get_categories2_1():
    return CATEGORIES2_1	
	
class BaseScraper(object):
	pass
	
#############################################################################	
def get_option(page, stype, soption):
	usefull = __get_usefull(stype)
	if soption == 'orderby':
		url = usefull['surl'] + '?type=serie&pid=%d&ps=20&orderby=name' % int(page-1)
	else:
		url = usefull['surl'] + '?type=serie&pid=%d&ps=20' % int(page-1)
	return _get_names(url, stype)

def get_serch_result(stype, search_string):
	usefull = __get_usefull(stype)
	params = {'keyword': search_string}
	url = usefull['surl'] + '?type=serie&pid=0&ps=1000&%s' % urllib.urlencode(params)
	return _get_names(url, stype)

def get_movies(name_id, stype):
	usefull = __get_usefull(stype)
	url = usefull['surl'] + '?type=seriedetail&id=%d' % int(name_id)
	tree, html = __get_tree(url)
	getmovies = {'title': '', 'thumb': '', 'source1': '', 'source2': ''}
	for item in tree.findAll('item'):         
		getmovies['title'] = item.entitle.string
		if item.picturename.string:
			getmovies['thumb'] = usefull['poster'] + item.picturename.string
		getmovies['source1'] = item.thailink.string
		getmovies['source2'] = item.subthailink.string
			
	movies = []
	if getmovies['source1']:
		m_title = getmovies['title'] + ' [THAI]'
		sc = 'source1'
		movies.append({
			'title': m_title,
			'thumb': getmovies['thumb'],
			'source': getmovies[sc]
		})
	if getmovies['source2']:
		m_title = getmovies['title'] + ' [SUBTHAI]'
		sc = 'source2'	
		movies.append({
			'title': m_title,
			'thumb': getmovies['thumb'],
			'source': getmovies[sc]
		})
	return movies

def get_episodes(name_id, stype):
	usefull = __get_usefull(stype)
	url = usefull['surl'] + '?type=serielink&ps=100&id=%d' % int(name_id)
	tree, html = __get_tree(url)
	pattern = re.compile("\<Link\>(?P<link>[^\<]*)\<\/Link\>\s*")
	total = re.finditer(pattern,html)
	bufferr = []
	for i in total:
		bufferr.append({'source' : i.group('link')})
	episodes = []
	for item in tree.findAll('item'):         
		episodes.append({
			'title': item.seriename.string,
			'part': item.partnumber.string,
			'date': item.lastupdated.string
		})
	count = 0
	for i in episodes:
		i.update(bufferr[count])
		count+=1
	log('_get_episodes got %d item' % len(episodes))
	return episodes

def get_new_episodes(stype):
	usefull = __get_usefull(stype)
	url = usefull['surl'] + '?type=serienews&ps=20&pid=0&device=dc9ee5e129b9633f875cec2dde8b9eaee7de9c443afd4091ab77b4dbd97e7669&version=ipad'
	tree, html = __get_tree(url)
	pattern = re.compile("\<link\>(?P<link>[^\<]*)\<\/link\>\s*")
	total = re.finditer(pattern,html)
	bufferr = []
	for i in total:
		bufferr.append({'source' : i.group('link')}) 
	episodes = []
	
	for item in tree.findAll('item'):
		if item.status.string == '0':
			item.status.string = '[Soon]'
		elif item.status.string == '1':
			item.status.string = '[Airing]'
		elif item.status.string == '2':
			item.status.string = '[Completed]'   
		episodes.append({
			'title': item.seriename.string,
			'part': item.partname.string,
			'thumb': usefull['poster'] + item.picturename.string,
			'date': item.lastupdated.string[:10],
			'status': item.status.string
		})
	count = 0
	for i in episodes:
		i.update(bufferr[count])
		count+=1
	log('_get_new_episodes got %d item' % len(episodes))
	return episodes

def get_links(stype):
	usefull = __get_usefull(stype)
	url = usefull['surl'] + '?type=All&pi=0&ps=20'
	tree, html = __get_tree(url)
	patFinderImg = re.compile('DefaultImage\":\"(.*?)\"')
	patFinderUrl = re.compile('Url1\":\"(.*?)\"')
	patFinderName = re.compile('Name\":\"(.*?)\"')
	findPatImg = re.findall(patFinderImg,html)
	findPatUrl = re.findall(patFinderUrl,html)
	findPatName = re.findall(patFinderName,html)
	bufferr = []
	links = []
	img = []
	for i in findPatImg:
		if i == '':
			img.append({'thumb': 'null'})
		else:
			img.append({'thumb': usefull['poster'] + i})
	for i in findPatName:
		bufferr.append({'title': i})
	for i in findPatUrl:
		if i == '':
			links.append({'source': 'null'})
		else:
			links.append({'source': i})
	count = 0
	for i in links:
		i.update(bufferr[count])
		count+=1
	count = 0
	for i in links:
		i.update(img[count])
		count+=1	
	return links
def _get_names(url, stype):
	tree, html = __get_tree(url)
	names = []
	for item in tree.findAll('item'):
		if stype != 'm_mo':
			if item.status.string == '0':
				item.entitle.string += ' [Soon]'
			elif item.status.string == '1':
				item.entitle.string += ' [Airing]'
			elif item.status.string == '2':
				item.entitle.string += ' [Completed]'
		if (item.dateshowtime.string != None) and (len(item.dateshowtime.string) > 4):
			item.dateshowtime.string = item.dateshowtime.string[-4:]
		if item.picturename.string == None:
			item.picturename.string = 'null'
		if item.entitle.string:
			names.append({
				'id': item.id.string,
				'title': item.entitle.string,
				'thumb': usefull['poster'] + item.picturename.string,
				'genre': item.type.string,
				'year': item.dateshowtime.string,
				'numberofep': item.numberofpart.string,
				'director': item.director.string,
				'plot': item.abstract.string,
				'prodcom': item.productioncompany.string,
				'studio': item.stationonair.string,
				'writer': item.written.string,
				'statusname': item.status.string,
				'trailer': item.trailer.string,
				'lastupdated': item.lastupdated.string
			})
	log('_get_names got %d item' % len(names))
	return names

def __get_tree(url):
	log('__get_tree opening url: %s' % url)
	req = urllib2.Request(url)
	req.add_header('User-Agent', usefull['uagent'])
	try:
		html = urllib2.urlopen(req).read()
	except urllib2.HTTPError, error:
		raise NetworkError('HTTPError: %s' % error)
	log('__get_tree got %d bytes' % len(html))
	tree = BeautifulSoup(html, convertEntities=BeautifulSoup.XML_ENTITIES)
	return tree, html

def __get_usefull(stype):
	if stype == 's_us':
		usefull['stype'] = 's_us'
		usefull['surl'] = 'http://series9.servicedooeii.com/serie9handler.ashx'
		usefull['poster'] = 'http://www.series9-admin.com/poster/'
		usefull['uagent'] = 'Series%209%20HD/2.0.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 's_kr':
		usefull['stype'] = 's_kr'
		usefull['surl'] = 'http://series8.servicedooeii.com/Serie8Handler.ashx'
		usefull['poster'] = 'http://www.series8-admin.com/poster/'
		usefull['uagent'] = 'Series%208%20HD/2.0.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 's_jp':
		usefull['stype'] = 's_jp'
		usefull['surl'] = 'http://series7.servicedooeii.com/serie7/service.ashx'
		usefull['poster'] = 'http://www.series7-admin.com/poster/'
		usefull['uagent'] = 'Series%207%20HD/2.0.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 's_an':
		usefull['stype'] = 's_an'
		usefull['surl'] = 'http://anime.servicedooeii.com/anime/service.ashx'
		usefull['poster'] = 'http://www.animefc-admin.com/poster/'
		usefull['uagent'] = 'AnimeFC%20HD/2.0.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 'sc_th':
		usefull['stype'] = 'sc_th'
		usefull['surl'] = 'http://seriesseries.servicedooeii.com/thaidrama.ashx'
		usefull['poster'] = 'http://www.series6-admin.com/poster/'
		usefull['uagent'] = 'Series%206%20HD/2.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 'sc_cn':
		usefull['stype'] = 'sc_cn'
		usefull['surl'] = 'http://seriesseries.servicedooeii.com/serie5.ashx'
		usefull['poster'] = 'http://www.series5-admin.com/poster/'
		usefull['uagent'] = 'Series%205/1.1 CFNetwork/609.1.4 Darwin/13.0.0'	
	elif stype == 'm_mo':
		usefull['stype'] = 'm_mo'
		usefull['surl'] = 'http://seriesseries.servicedooeii.com/moviefc.ashx'
		usefull['poster'] = 'http://www.moviefc-admin.com/poster/'
		usefull['uagent'] = 'MovieFC%20HD/1.0 CFNetwork/609 Darwin/13.0.0'
	elif stype == 'l_sp':
		usefull['stype'] = 'l_sp'
		usefull['surl'] = 'http://sportchannel.serviceseries.com/Channel.ashx'
		usefull['poster'] = 'http://sportchannel-admin.com/info/'
		usefull['uagent'] = 'Sport%20CH/1.0 CFNetwork/609.1.4 Darwin/13.0.0'
	elif stype == 'l_kd':
		usefull['stype'] = 'l_kd'
		usefull['surl'] = 'http://kidchannel.serviceseries.com/KidchannelHandler.ashx'
		usefull['poster'] = 'http://kidchannel-admin.com/info/'
		usefull['uagent'] = 'Kid%20CH/1.1 CFNetwork/609.1.4 Darwin/13.0.0'
	elif stype == 's_ct':
		usefull['stype'] = 's_ct'
		usefull['surl'] = 'http://cartoonlive.serviceseries.com/CartoonHandler.ashx'
		usefull['poster'] = 'http://www.cartoonlive-admin.com/poster/'
		usefull['uagent'] = 'CartoonLive/1.0 CFNetwork/609.1.4 Darwin/13.0.0'
	return usefull

def log(msg):
	print(u'uPlayHD log => %s Scraper: %s' % (usefull['uagent'], msg))
