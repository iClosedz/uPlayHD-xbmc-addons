#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    Copyright (C) 2013 iClosedz (iClosedz.blogspot.com)
#	 Thanks to sphere (https://github.com/dersphere)
#	
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import urllib2,urllib,re,json,random
usefull = {'surl': '', 'uagent': ''}
CATEGORIES_ru = (
	{'title': 'latest', 'path': 'show_ru_names', 'soption': 'latest'},
	#{'title': 'orderby', 'path': 'show_names', 'soption': 'orderby'},
	{'title': 'search', 'path': 'show_search', 'soption': 'search'},
    {'title': 'orderby_az', 'path': 'show_orderby', 'soption': 'orderby_az3'}
)

def get_categories_ru():
    return CATEGORIES_ru
	
def get_random():
	return str(random.randrange(10000000,9999999999))
	
def get_names(stype, soption, key):
	usefull = __get_usefull()
	if soption == 'latest':
		url = usefull['surl'] + '?r=api/getUpdate&rd=%s' % get_random()
	elif soption == 'orderby_az3':
		if stype == 's_ru_kr':
			contry = 'kr'
		else:
			contry = 'jp'
		url = usefull['surl'] + '?r=api/search&rd=%s&type=%s&range=%s&k=&startRec=0' % (get_random(), contry, key)
	elif soption == 'search':
		url = usefull['surl'] + '?r=api/search&rd=%s&type=&range=&k=%s&startRec=0' % (get_random(), key)
	return _get_names(url, stype, soption)

def get_episodes(name_id):
	usefull = __get_usefull()
	url = usefull['surl'] + '?r=api/getChapter&id=%s&rd=%s' % (name_id, get_random())
	json_data = __get_json(url)
	episodes = []
	for item in json_data:
		episodes.append({
			'title': item['title'],
			'part': item['number'],
			'thumb': item['img'],
			'date': item['mo_time'],
			'source': item['filename']
		})
	log('get_episodes got %d item' % len(episodes))
	return episodes		

def _get_names(url, stype, soption):
	json_data = __get_json(url)
	names = []
	for item in json_data:
		if item['title']:
			if str(item['status']) == '0':
				item['status'] = ' [Soon]'
			elif str(item['status']) == '1':
				item['status'] = ' [Airing]'
			elif str(item['status']) == '2':
				item['status'] = ' [Completed]'
			elif str(item['status']) == '3':
				item['status'] = ' [ON Break]'
			if item['img'] == None:
				item['img'] = 'null'
			if soption == 'latest':
				item['status'] += ' ('+item['mo_time']+')'
				item['detail'] = ''
			names.append({
				'id': item['id'],
				'title': item['title'],
				'thumb': item['img'],
				#'genre': item['Type'],
				#'year': item['DateShowTime'],
				#'numberofep': item['NumberOfPart'],
				#'director': item['Director'],
				'plot': item['detail'],
				#'prodcom': item['ProductionCompany'],
				#'studio': item['StationOnAir'],
				#'writer': item['Written'],
				'statusname': item['status'],
				#'trailer': item['TrailerLink'],
				#'lastupdated': item['LastUpdated2']
			})
	log('_get_names got %d item' % len(names))
	return names

#GET JSON
def __get_json(url):
	#log('__get_tree opening url: %s' % url)
	req = urllib2.Request(url)
	req.add_header('User-Agent', usefull['uagent'])
	try:
		html = urllib2.urlopen(req).read()
	except urllib2.HTTPError, error:
		raise NetworkError('HTTPError: %s' % error)
	log('__get_tree got %d bytes' % len(html))
	json_data = json.loads(html)
	return json_data
'''
def __post_json(query_args):
	req = urllib2.Request(usefull['surl'])
	req.add_data(urllib.urlencode(query_args))
	req.add_header('User-Agent', usefull['uagent'])
	#log('__get_tree_new opening url: %s' % usefull['surl'])
	#log('__get_tree_new use param: %s' % req.get_data())
	try:
		html = urllib2.urlopen(req).read()
	except urllib2.HTTPError, error:
		raise NetworkError('HTTPError: %s' % error)
	log('__get_tree_new got %d bytes' % len(html))
	json_data = json.loads(html)
	return json_data	
'''
def __get_usefull():
	usefull['surl'] = 'http://112.121.150.248/index.php'
	usefull['uagent'] = 'RUindy Series HD 2.2 (iPad; iPhone OS 6.0.1; th_TH)'
	return usefull
	
def log(msg):
	print(u'uPlayHD log => %s Scraper: %s' % (usefull['uagent'], msg))
